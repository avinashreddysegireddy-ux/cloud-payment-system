# Cloud Payment System (Simple Base Version)

## Setup
```bash
pip install flask
python app.py
```
Server runs at http://localhost:5000

## Endpoints
| Method | Path | Body |
|---|---|---|
| POST | /accounts | `{"owner": "Alice", "currency": "USD"}` |
| GET | /accounts/<id> | |
| POST | /accounts/<id>/deposit | `{"amount": 100}` |
| POST | /accounts/<id>/withdraw | `{"amount": 25}` |
| POST | /transfer | `{"from_account": "...", "to_account": "...", "amount": 10}` |
| GET | /accounts/<id>/transactions | |
| GET | /health | |

## Quick test
```bash
curl -X POST localhost:5000/accounts -H "Content-Type: application/json" -d '{"owner":"Alice"}'
curl -X POST localhost:5000/accounts/<ID>/deposit -H "Content-Type: application/json" -d '{"amount":100}'
```

## Next steps for a real system
Authentication (JWT), idempotency keys, a real database (PostgreSQL), audit logging, and a payment gateway integration.
